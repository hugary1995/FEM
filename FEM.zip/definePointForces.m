function Fpoint = definePointForces(NodalCoord)

Nnodes = size(NodalCoord,1);
Fpoint = zeros(2*Nnodes,1);

end